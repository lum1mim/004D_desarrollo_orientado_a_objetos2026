package clase3;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        mostrarMenu();


    }

    static void mostrarMenu(){
        String opcion_elegida;
        Scanner scanner = new Scanner(System.in);
        boolean iniciar_menu = true;
        Personaje personaje_jugador = new Personaje();
        System.out.println("***Binvenidos al mundo de westeros***");


        while (iniciar_menu) {
            System.out.println("1.- Crear personajes");
            System.out.println("2.- Ver personaje");
            System.out.println("3.- salir");
            System.out.println("por favor ingrese una opcion");

            opcion_elegida = scanner.nextLine();
            System.out.println("La opcion escogida por el usuario es: " + opcion_elegida);
        
        // accions en funcion de un valor o sus posibles valores valores
            switch (opcion_elegida) {
            case "1":
                System.out.println("creacion de personaje");

                System.out.println("Como llamaras a tu heroe??");
                personaje_jugador.nombre = scanner.nextLine();
                System.out.println("el nombre del perosnaje es: "+ personaje_jugador.nombre);

                System.out.println("cual sera el apellido de tu heroe??");
                personaje_jugador.apellido = scanner.nextLine();
                System.out.println("el nombre y apellido del personaje es: " + personaje_jugador.nombre +" "+personaje_jugador.apellido);

                System.out.println("indique la vida del heroe");
                //personaje_jugador.vida = Integer.parseInt(scanner.nextLine());
                //ya asi no pq es inseguro
                personaje_jugador.setearVida(Integer.parseInt(scanner.nextLine()));
                
                break;
            case "2":
                System.out.println("ver personaje");
                System.out.println("nombre: "+ personaje_jugador.nombre);
                System.out.println("apellido: " + personaje_jugador.apellido);
                System.out.println("vida: " + personaje_jugador.verVida());
                break;
            case "3":
                System.out.println("bye bye, have a nice day");
                iniciar_menu = false;
                break;
            default:
                System.out.println("porfavor, ingrese una de las opciones permitidas");
                break; 
            }
        }
    
    }
}
